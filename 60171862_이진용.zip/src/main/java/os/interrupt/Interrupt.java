package main.java.os.interrupt;

public interface Interrupt {
    EInterrupt getEInterrupt();
}
