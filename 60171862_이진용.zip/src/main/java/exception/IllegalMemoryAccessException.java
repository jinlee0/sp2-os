package main.java.exception;

public class IllegalMemoryAccessException extends RuntimeException {
}
