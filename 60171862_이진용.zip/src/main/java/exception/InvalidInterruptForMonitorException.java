package main.java.exception;

public class InvalidInterruptForMonitorException extends RuntimeException {
}
