package main.java.exception;

public class InvalidInterruptCodeException extends RuntimeException{
}
