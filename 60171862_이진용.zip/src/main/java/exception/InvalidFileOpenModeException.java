package main.java.exception;

public class InvalidFileOpenModeException extends RuntimeException {
}
