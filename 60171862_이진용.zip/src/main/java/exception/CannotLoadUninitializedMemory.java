package main.java.exception;

public class CannotLoadUninitializedMemory extends RuntimeException {
}
