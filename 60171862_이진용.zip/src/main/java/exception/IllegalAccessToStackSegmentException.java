package main.java.exception;

public class IllegalAccessToStackSegmentException extends RuntimeException {
}
