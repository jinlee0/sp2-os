package main.java.exception;

public class NotSuchFileIdException extends RuntimeException {
}
