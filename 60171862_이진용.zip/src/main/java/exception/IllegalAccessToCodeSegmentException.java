package main.java.exception;

public class IllegalAccessToCodeSegmentException extends RuntimeException {
}
