package main.java.exception;

public class ProcessNotFound extends RuntimeException {
}
