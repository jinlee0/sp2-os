package main.java.exception;

public class InvalidExeFormatException extends RuntimeException {
}
