package main.java.exception;

public class IllegalAccessToHeapSegmentException extends RuntimeException {
}
